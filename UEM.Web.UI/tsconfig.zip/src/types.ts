export type Agent = { agentId: string; lastSeenAt?: string | null; online?: boolean }

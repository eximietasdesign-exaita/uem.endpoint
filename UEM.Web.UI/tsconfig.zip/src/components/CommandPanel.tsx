import { useState } from 'react'
import { broker } from '@/lib/api'
import { useSelection } from '@/state/useSelection'

export default function CommandPanel(){
  const [cmd, setCmd] = useState(' -a')
  const [busy, setBusy] = useState(false)
  const selection = useSelection()

  const run = async () => {
    if (!cmd.trim() || selection.selected.length === 0) return
    setBusy(true)
    try {
      for (const id of selection.selected) {
        await broker.post('/api/commands', { agentId: id, type: 'run-shell', payload:{ command: cmd } })
      }
    } finally { setBusy(false) }
  }

  return (
    <div className="rounded border bg-white p-4 space-y-3">
      <div className="text-sm text-gray-600">Command Console</div>
      <textarea className="w-full border rounded p-2 h-28" value={cmd} onChange={e=>setCmd(e.target.value)} />
      <div className="flex items-center gap-2">
        <button onClick={run} disabled={busy || selection.selected.length===0 || !cmd.trim()}
          className="px-4 py-2 rounded bg-black text-white disabled:opacity-50" title={selection.selected.length===0?'Select at least one agent':(!cmd.trim()?'Enter a command':'')}>Run on {selection.selected.length}</button>
        <button onClick={()=>setCmd('')} className="text-sm text-gray-600 hover:underline">Clear</button>
      </div>
    </div>
  )
}

namespace UEM.Endpoint.Agent.Services;
public sealed class ConfigSyncService
{
    public Task SyncIfNeededAsync(CancellationToken ct) => Task.CompletedTask;
}
